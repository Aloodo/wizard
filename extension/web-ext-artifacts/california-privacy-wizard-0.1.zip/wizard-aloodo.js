var el = document.getElementById('install-extension');

el.textContent = "Thank you for installing the California Privacy Wizard browser extension.";

